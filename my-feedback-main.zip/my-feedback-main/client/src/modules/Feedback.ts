export interface Feedback {
    rating: number;
    text: string;
    id?: string;
}
